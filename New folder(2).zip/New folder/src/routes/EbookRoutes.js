const express = require("express");
const EbookRouter = express.Router();

const Bookdata =require('../model/Bookdata');

//using express.router class for book router
//called function

function router(nav){


var books=[
    { title:'The scarlet letter',
      
   desc:"The Scarlet Letter sheds light on the nineteenth century in which it was written, as Hawthorne explores his ambivalent relations with his Puritan forebears",
      img :"8231540-M.jpg"   // static file is accessed it should be in Public as mentioned
    },
    { title:'Just mercy',
    
    desc:"Just Mercy is an unforgettable account of an idealistic, gifted young lawyer’s coming of age, a moving window into the lives of those he has defended, and an inspiring argument for compassion in the pursuit of true justice",
    img:"8352503-N.jpg"   
    },
    { title:'Double Take',
    
    desc:'An fbi thriller which takes the reader to a third world of mystery',

    img:"8458060-O.jpg"   
    },
    { title:'The sun is Also a star',
    
    desc:"College-bound romantic Daniel Bae and Jamaica-born pragmatist Natasha Kingsley meet and fall for each other  over one magical day amidst the fervor and flurry of New York City",
    img:"392533-P.jpg"  
    },
    { title:'Harry potter',
    
    desc:" As Harry enters his fifth year at wizard school, Lord Voldemort’s rise has opened a rift in the wizarding world between those who believe the truth about his return, and those who prefer to believe it’s all madness and lies - just more trouble from Harry Potter",
    img:""  
    },
    { title:'Matilda',
   
    desc:"MATILDA IS A SWEET, 5-YEAR-OLD GENIUS with horrible, mean parents. Fortunately, she has a great time giving them what they deserve. But at school things are different. At school there's Miss Trunchbull: two hundred pounds of kid-hating headmistress. Giving Miss Trunchbull what she deserves will take more than a genius...it will take a superhuman genius! ",

    img:"shake1.jpg"  
    }
    
    ]  
    
    //Method 2 
    EbookRouter.get('/',function(req,res){
       
        Bookdata.find()
       .then(function(Ebook){
        res.render("Ebooks",
        {
            
            nav,
            title:'Library',
            Ebook    // pass books array along with the response(route)
        }); 
       })
     
    });
    // for book single page
    EbookRouter.get('/:id',function(req,res){
        const id=req.params.id;
        Bookdata.findOne({_id: id})
        .then(function(book){
            res.render('book',
            {
            // nav:[{link:'/books',name:'Books'},
            // {link:'/authors',name:'Author'}],
            nav,
            title:'library',
            Ebook
            });
        })
       
    });

//     //deletion
// EbookRouter.get('/:id/delete',function(req,res){
//     const id=req.params.id;
//    bookData.remove({_id:id})
//      .then(function(book){
//     res.redirect('/Ebook');  
// });
// });
// // //updation
// EbookRouter.get('/:id/update',function(req,res){
//     const id=req.params.id;
//     bookData.findOne({_id:id})
//     .then(function(book){
//     res.render('book',{
//     nav,
//     title:'Library',
//    book   
//     });
// });
// });

// EbookRouter.post('/:id/update/ok',function(req,res){ 
//     const id=req.params.id;      
    
//    var values= bookData.updateOne({_id:req.params.id},{title:req.body.title,
// //     author:req.body.author,genre:req.body.genre,image:req.body.image},function(err,docs){
// // if(err)
// // res.json(err)
// // else
// // res.redirect('/book');
// Description:req.body.author,image:req.body.image})
// .then(function(book){
//      res.redirect('/book');
    
//     });  
// });


EbookRouter.get('/book/edit/:id',function(req,res){
    const id= req.params.id;
    Bookdata.findOne({_id: id})
    .then(function(book){
      res.render('Bookedit', 
      {nav,
        title:'library',
        book
    })
    })
  
EbookRouter.post('/book/update',function(req,res){
  var id=req.body.id;  
  var title=req.body.title;  
  var Description=req.body.author;  
   
  var image=req.body.image;  
Bookdata.updateOne({_id:id},{$set:{title:title,author:author,genre:genre,image:image}},function(req,res){

})
res.redirect('/Ebooks');
})


booksRouter.get('/delete/:id',function(req,res){
  var id=req.params.id;
Bookdata.findByIdAndRemove(req.params.id,function(req,res){

})
res.redirect('/Ebooks');
})
})
  


    return EbookRouter;
}
    module.exports=router;

