const express = require("express");
    const app = new express(); 

    const nav = [
        {
            link:'/',name:'home',
           
        },
       
        
        {
            link:'/register',name:'Register',
           
        },
        {
            link:'/login',name:'login',
           
        },
        {
            link:'/Ebooks',name:'Ebooks',
           
        },
        {
            link: '/admin',name:'Add Book',
        }
    ]
    
    // const homeRouter =require('./src/routes/homeroutes')(nav)
     const EbookRouter =require('./src/routes/EbookRoutes')(nav)
     const LoginRouter =require('./src/routes/loginRoutes')(nav)
     const registerRouter =require('./src/routes/registerRoutes')(nav)
     const adminRouter =require('./src/routes/adminRoutes')(nav)
     
    
     app.use(express.urlencoded({extended:true}));
     app.use(express.static(`${__dirname}/public`)); 
    app.set('view engine','ejs');
    app.set('views','./src/views');
    
    
    app.use('/Ebooks',EbookRouter);
    // app.use('/home',homeRouter);
    app.use('/login',LoginRouter);
    app.use('/Register',registerRouter);
    app.use('/admin',adminRouter);
     app.get("/",(req,res)=>{
         res.render("home",
        {
            nav,
            title:'Library'
        });
    
     });
    
    
    
    
     
     app.listen(5000);
     


